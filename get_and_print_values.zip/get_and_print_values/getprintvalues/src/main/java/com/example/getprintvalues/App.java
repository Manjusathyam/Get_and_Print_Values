package com.example.getprintvalues;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App {
    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.get("https://demoqa.com/text-box");
        driver.manage().window().maximize();

        // step 1: submitting the form:
        WebElement fullname = driver.findElement(By.id("userName"));
        fullname.sendKeys("Sathyam");

        WebElement email = driver.findElement(By.id("userEmail"));
        email.sendKeys("sathyam@gmail.com");

        WebElement currentAddress = driver.findElement(By.id("currentAddress"));
        currentAddress.sendKeys("kk nagar");

        WebElement permanentAddress = driver.findElement(By.id("permanentAddress"));
        permanentAddress.sendKeys("kk nagar");

        WebElement submit = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/form/div[5]/div/button"));
        submit.click();

        // step 2: Get values from the output:
        WebElement fulnameoutput = driver.findElement(By.id("name"));
        WebElement emailOutput = driver.findElement(By.id("email"));

        // step 3: Print the values:
        System.out.println(fulnameoutput.getText());
        System.out.println(emailOutput.getText());
        
        driver.quit();
    }
}